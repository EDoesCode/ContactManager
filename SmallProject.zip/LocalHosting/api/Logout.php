<?php
    // Start a session
    session_start();
    $_SESSION["AccountID"] = 0;
?>
